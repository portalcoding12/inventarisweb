<br>
<div class="panel panel-default">
	<div class="panel-body bg-primary">
		<div class="container">
			<div class="row">
				<div class="col-md-1 col-md-offset-0" style="margin-top:20px;">
					<span><i class="fa fa-graduation-cap fa-5x"></i></span>
				</div>
				<div class="col-md-6 text-justify">
					<h2>Aplikasi Inventaris Sekolah</h2>
					<h4>Inventaris SMK Negeri 1 Lahat</h4>
				</div>
			</div>
		</div>
	</div>
</div>
