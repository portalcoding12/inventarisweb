<div class="modal fade" id="logout" tabindex="-1" role="dialog" aria-labelledby="" aria-hidden="true" style="margin-top:260px;margin-left:0px;">
	<div class="modal-dialog">
		<div class="modal-content">
			<div class="modal-body">
					<h3><span><i class="fa fa-info-circle fa-1x"></i></span>  Anda yakin ingin keluar ? </h3>
			</div>
			<div class="modal-footer">
				<a href="/inventaris/logout.php" class="btn btn-primary">Lanjutkan <span><i class="fa fa-forward"></i></span></a>
				<button type="button" class="btn btn-danger" data-dismiss="modal"><i class="fa fa-close"></i> Batal</button>
			</div>
		</div>
	</div>
</div>
