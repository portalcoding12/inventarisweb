<meta charset="utf-8">
<meta http-equiv="X-UA-Compatible" content="IE=edge">
<meta name="viewport" content="width=device-width, initial-scale=1">
<link rel="icon" href="/inventaris/img/icon.png" type="image/x-icon">
<title>Aplikasi Inventaris Sarana dan Prasarana SMK</title>

<!-- Bootstrap -->
<link rel="stylesheet" href="/inventaris/bootstrap/css/bootstrap.min.css">
<link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/font-awesome/4.7.0/css/font-awesome.min.css">
<link rel="stylesheet" type="text/css" href="/inventaris/bootstrap/css/style.css">
